TELEGRAM_BOT_TOKEN = "YOUR_BOT_API_TOKEN"
ADMIN_ID = 123456789
LOG_CHANNEL_ID = -100123456789
UPDATE_CHANNEL = "https://t.me/your_update_channel"
DISCUSSION_GROUP = "https://t.me/your_discussion_group"
